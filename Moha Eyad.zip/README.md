# Discord-Global-Slash-Command-Bot
A discord slash command made using javascript easy to setup and control

# Suscribe to KP 18 Gamer
- [Subscribe](https://www.youtube.com/channel/UCo2iuPS4FZ8V6H_ct2F8-2A/featured)

## This bot was made Romeo#0700, do not remove credits or you will have copyright issues.
### Make sure to join The servers below:
- [The Capital Club](https://discord.gg/gU7XAxTpX5)

## Must Important
- Invite the bot with `applications.commands` oauth2 scope.
- The bot won't work without it.


##### Modification 
- Add your guildID in index.js
- Add Bot ID in `botinfo.js`, `help.js` 
- Edit `invite.js` bot invite link
- run it by `node index.js` 


![image](https://user-images.githubusercontent.com/74746579/119320781-a8084880-bc9b-11eb-9f34-aa8351183424.png)
- Go secrets[Environment Variable] and add TOKEN and paste token there if you are in repl.it or put  add token in .env file

- Run in repl.it
- [Click Here](https://replit.com/@GamingDiwas/Discord-Global-Slash-Command-Bot#README.md)


### Join My Server

